## 0.2.3 - Fixed some bug & small refactoring
* fixed bug on css and html syntax (see #1, #2).
* remove very-light-gray and used syntax-text-color instead.

## 0.1.0 - First Release
* Let's begin plain.
