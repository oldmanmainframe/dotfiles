// this is comment

/*
 * this is comment
 */

var hello = (function() {
  function Main() {

  }

  Main.prototype.method = function(arg) {
    return "hello world";
  };

  return Main;
});