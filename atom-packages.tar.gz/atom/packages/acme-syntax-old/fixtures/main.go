package main

import "fmt"

func MyFunc(arg string) {

}

func main() {
	fmt.Println("Hello, World")
}
