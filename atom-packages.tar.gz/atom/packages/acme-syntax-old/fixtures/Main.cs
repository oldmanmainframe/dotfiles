using System;

public class AppMain {

    private string field1;

    public Object obj;

    /// <summary>
    ///   The main entry point for the application
    /// </summary>
    [STAThread]
    public static void Main(string[] args)
    {
        Console.Writeln("Hello World");
        var isABoolean = true;
        isABoolean = false;

        var thisIsNull = null;
    }
}
