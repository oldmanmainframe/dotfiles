# Ascetic Syntax
A minimal syntax theme inspired by [this abandoned scheme](https://github.com/hartator/no-syntax-highlighting-syntax).

![screenshot](https://user-images.githubusercontent.com/1669027/39238527-20b8e10e-4887-11e8-8662-9d28a592e13f.png)
