# plain-syntax theme

A simple and plain syntax.

![A screenshot of your theme](https://dl.dropboxusercontent.com/u/15561283/plain-syntax.png)

## I have a lot of work to do.

  - [ ] make less clean (refactoring, remove duplication).
  - [ ] support more language.
