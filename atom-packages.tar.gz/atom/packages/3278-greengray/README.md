# yospos-syntax

A syntax theme for Atom based on Something Awful's YOSPOS subforum.

![Screenshot](https://raw.githubusercontent.com/lukehorvat/yospos-syntax/master/screenshot.png)
