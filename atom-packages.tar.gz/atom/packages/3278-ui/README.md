# KSX Matrix UI

A fork of [hacking-the-kernel-ui](https://github.com/heisian/hacking-the-kernel-ui) with some tweaks.

Matching syntax themes:
 - [ksx-matrix](https://atom.io/themes/ksx-matrix)
 - [hacking-the-kernel](https://atom.io/themes/hacking-the-kernel)

## Preview
![screenshot](https://raw.githubusercontent.com/ksxatompackages/ksx-matrix-ui/master/screenshot.png)
