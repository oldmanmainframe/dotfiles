#include <stdio.h>

int main() {
	printf("%d", testanymethod());
}
